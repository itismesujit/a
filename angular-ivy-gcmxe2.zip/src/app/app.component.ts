import { Component, VERSION } from '@angular/core';
import { Subscription } from 'rxjs';
import { DataService } from './services/data.service';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  userSub$: Subscription;
  searchSub$: Subscription;
  users: any[] = [];
  latestCheck: boolean = false;

  constructor(private data: DataService) {}

  getUsers() {
    this.userSub$ = this.data.getUsers().subscribe({
      next: (users) => console.log(`Data received`, users),
      error: (err) => console.error(err),
      complete: () => console.log('User request completed!!!'),
    });
  }

  searchUsers(searchUserInp: HTMLInputElement): void {
    console.log(searchUserInp.value);
    console.log(this.latestCheck);

    if (searchUserInp.value.length > 0) {
      this.users = [];
      this.searchSub$ = this.data
        .searchUsers(searchUserInp.value, this.latestCheck)
        .subscribe({
          next: (users) => {
            console.log('User list', users);
            this.users = <any>users;
          },
          error: (err) => console.error(err),
          complete: () => console.log('Search completed!!!'),
        });
    }
  }
}
